﻿package cl.storeflow.warehouse.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

val StoreFlowShapes = Shapes(
    small      = RoundedCornerShape(6.dp),
    medium     = RoundedCornerShape(10.dp),
    large      = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(50.dp),
)
